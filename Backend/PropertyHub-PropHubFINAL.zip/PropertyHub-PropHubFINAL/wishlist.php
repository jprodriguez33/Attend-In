<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>House Buying Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<nav>
			<div class="search-bar">
				<form action="buyer.php" method="post">
				<input name="search" type="text" placeholder="Search for max price...">
				<button type="submit">Search</button>
				</form>
			</div>
			<div class="user-profile">
				<a href="login.html">Log In</a>
				<a href="signup.html">Sign Up</a>
			</div>
		</nav>
	</header>

	<main>
		<section class="banner">
			<h1 id="welcome">Welcome new buyer!</h1>
			<p id="thank you">Thank You for choosing us. we are glad to help you!</p>
		</section>

		<section class="featured-homes">
        <a href='./buyer.php'>Back to Homepage</a>
			<h2>Wishlist</h2>
			<div>
<?php 
session_start();
$userID=$_SESSION["user"];
$id = $_GET["id"];
$host = "localhost";
$user = "eharrigan1";
$pass = "eharrigan1";
$dbname = "eharrigan1";

//get values from html
$username = $_POST['username'];
$pw = $_POST['pw'];

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection if ($conn->connect_error) {
if ($conn->connect_error) {
    echo "Could not connect to server\n";
    die("Connection failed: " . $conn->connect_error);
}

$insert="INSERT INTO WISHLIST(user, house)
         VALUES ('$userID', '$id');";
if($conn->query($insert) === TRUE) {
} else {
    echo "cant insert the same house \n";
}

$query = "SELECT *
          FROM WISHLIST w
          INNER JOIN HOUSES h
          WHERE w.user = '$userID' AND h.id=w.house;";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        
        while($row = $result->fetch_assoc()){

        echo "<div class='home-card'>
						<img src='./house.jpg' alt='Featured Home'>
						<h3>".$row["loc"]."</h3>
						<p>$".$row["price"]."</p>
                        <p>number of rooms: ".$row["numRooms"]."</p>
					    </div>";
        }
    } else {
        echo "wishlist not found.";
    }

?>
</div>
		</section>
	</main>


</body>
</html>
