<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>House Buying Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<nav>
			<div class="search-bar">
				<form action="buyer.php" method="post">
				<input name="search" type="text" placeholder="Search for max price...">
				<button type="submit">Search</button>
				</form>
			</div>
			<div class="user-profile">
				<a href="login.html">Log In</a>
				<a href="signup.html">Sign Up</a>
			</div>
		</nav>
	</header>

	<main>
		<section class="banner">
			<h1 id="welcome">Welcome new buyer!</h1>
			<p id="thank you">Thank You for choosing us. we are glad to help you!</p>
		</section>

		<section class="featured-homes">
			<h2>Featured Homes</h2>
			<div>
			<?php
				$price = $_POST["search"];
                $host="localhost";
                $user="eharrigan1";
                $pass="eharrigan1";
                $dbname="eharrigan1";
                
                $conn = new mysqli($host, $user, $pass, $dbname);
				if($price==null){
					$query="SELECT * 
        		FROM HOUSES h";
        		$result=$conn->query($query);
				if($result->num_rows>0){
					while($row=$result->fetch_assoc()){
						echo "<div class='home-card'>
						<img src='./house.jpg' alt='Featured Home'>
						<h3>".$row["loc"]."</h3>
						<p>$".$row["price"]."</p>
						<a href='./details.php?id=".$row["id"]."'>View Details</a>
						<a href='./wishlist.php?id=".$row["id"]."?user=".$_SESSION["user"]."'>add to wishlist</a>
					    </div>";
					}
				}
				}else{
					$query="SELECT * 
        		FROM HOUSES h
				WHERE h.price<='$price'
				ORDER BY h.price DESC";
        		$result=$conn->query($query);
				if($result->num_rows>0){
					while($row=$result->fetch_assoc()){
						echo "<div class='home-card'>
						<img src='./house.jpg' alt='Featured Home'>
						<h3>".$row["loc"]."</h3>
						<p>$".$row["price"]."</p>
						<a href='./details.php?id=".$row["id"]."'>View Details</a>
						<a href='./wishlist.php?id=".$row["id"]."?user=".$_SESSION["user"]."'>add to wishlist</a>
					    </div>";
					}
				}
				}

			?>
			</div>
		</section>
	</main>


</body>
</html>

<?php 
$conn->close();
?>