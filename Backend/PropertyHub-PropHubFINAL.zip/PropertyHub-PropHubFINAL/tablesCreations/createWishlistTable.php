<?php

$host = "localhost";
$user = "eharrigan1";
$pass = "eharrigan1";
$dbname = "eharrigan1";

// Create connection

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection if ($conn->connect_error) {
if ($conn->connect_error) {

    echo "Could not connect to server\n";
    die("Connection failed: " . $conn->connect_error);

}

$sql = "CREATE TABLE WISHLIST (
    user int(6),
    house int(6),
    CONSTRAINT
        PRIMARY KEY (user, house));";

if($conn->query($sql) === TRUE) {
    echo "Table WISHLIST created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>