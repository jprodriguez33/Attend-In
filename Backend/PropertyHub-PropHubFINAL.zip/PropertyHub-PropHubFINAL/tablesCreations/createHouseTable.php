<?php

$host = "localhost";
$user = "eharrigan1";
$pass = "eharrigan1";
$dbname = "eharrigan1";

// Create connection

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection if ($conn->connect_error) {
if ($conn->connect_error) {

    echo "Could not connect to server\n";
    die("Connection failed: " . $conn->connect_error);

}

$sql = "CREATE TABLE HOUSES (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loc VARCHAR(30) NOT NULL,
    price VARCHAR(30) NOT NULL,
    numRooms INT(2) NOT NULL);";

if($conn->query($sql) === TRUE) {
    echo "Table HOUSES created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$insert = "INSERT INTO HOUSES (loc, price, numrooms)
           VALUES
           ('123 Main St', 350000, 3),
           ('456 Oak Ave', 500000, 4),
           ('789 Elm St', 700000, 5),
           ('1010 Maple Dr', 900000, 6),
           ('1313 Pine St', 400000, 3),
           ('1515 Cedar Ave', 550000, 4),
           ('1717 Birch Ln', 800000, 5),
           ('1919 Spruce St', 1200000, 6),
           ('2121 Oak St', 650000, 4),
           ('2323 Maple Ave', 950000, 5);
           ";
if($conn->query($insert) === TRUE) {
    echo "data inserted successfully\n";
} else {
    echo "Error inserting table: " . $conn->error;
}

$conn->close();
?>
