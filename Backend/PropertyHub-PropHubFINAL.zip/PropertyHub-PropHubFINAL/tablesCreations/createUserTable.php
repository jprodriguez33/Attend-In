<?php

$host = "localhost";
$user = "eharrigan1";
$pass = "eharrigan1";
$dbname = "eharrigan1";

// Create connection

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection if ($conn->connect_error) {
if ($conn->connect_error) {

    echo "Could not connect to server\n";
    die("Connection failed: " . $conn->connect_error);

}

$sql = "CREATE TABLE USERS (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL,
    email VARCHAR(30) NOT NULL,
    pw VARCHAR(30) NOT NULL);";

if($conn->query($sql) === TRUE) {
    echo "Table USERS created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>