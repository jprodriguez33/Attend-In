<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>House Buying Website</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
		<nav>
			<div class="search-bar">
				<form action="buyer.php" method="post">
				<input name="search" type="text" placeholder="Search for max price...">
				<button type="submit">Search</button>
				</form>
			</div>
			<div class="user-profile">
				<a href="login.html">Log In</a>
				<a href="signup.html">Sign Up</a>
			</div>
		</nav>
	</header>

	<main>
		<section class="banner">
			<h1 id="welcome">Welcome new buyer!</h1>
			<p id="thank you">Thank You for choosing us. we are glad to help you!</p>
		</section>

		<section class="featured-homes">
        <a href='./buyer.php'>Back to Homepage</a>
			<h2>More Details</h2>
			<div>
<?php
    $id = $_GET["id"];

    $host = "localhost";
    $user = "eharrigan1";
    $pass = "eharrigan1";
    $dbname = "eharrigan1";
    
    $conn = new mysqli($host, $user, $pass, $dbname);

    $query = "SELECT * FROM HOUSES WHERE id = '$id'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Display the house details here
        echo "<div class='home-card'>
						<img src='./house.jpg' alt='Featured Home'>
						<h3>".$row["loc"]."</h3>
						<p>$".$row["price"]."</p>
                        <p>number of rooms: ".$row["numRooms"]."</p>
					    </div>";
        
    } else {
        echo "House not found.";
    }
    $conn->close();
?>
			</div>
		</section>
	</main>


</body>
</html>
