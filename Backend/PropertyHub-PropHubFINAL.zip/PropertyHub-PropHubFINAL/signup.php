<?php
$host = "localhost";
$user = "eharrigan1";
$pass = "eharrigan1";
$dbname = "eharrigan1";

//get values from html
$username = $_POST['username'];
$email = $_POST['email'];
$pw = $_POST['pw'];

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    echo "Could not connect to server\n";
    die("Connection failed: " . $conn->connect_error);
}

//check if username or email already exists

$sql = "INSERT INTO USERS (username, email, pw) 
        VALUES ('$username', '$email', '$pw');";

if($conn->query($sql) === FALSE) {
    echo "Error: " . 
    $conn->error;
} else {
    header('Location: login.html');
}

$conn->close();
?>