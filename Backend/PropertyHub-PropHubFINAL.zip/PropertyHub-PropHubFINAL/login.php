<?php
//edit still

$host = "localhost";
$user = "eharrigan1";
$pass = "eharrigan1";
$dbname = "eharrigan1";

//get values from html
$username = $_POST['username'];
$pw = $_POST['pw'];

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection if ($conn->connect_error) {
if ($conn->connect_error) {
    echo "Could not connect to server\n";
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT pw FROM USERS WHERE username = '$username';";

$result = $conn->query($sql);
$row = $result->fetch_assoc();

if($row['pw'] == $pw){
    header('Location: buyer.php');
} else {
    echo 'incorrect username/password';
}

$conn->close();

?>
